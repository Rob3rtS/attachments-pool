python3 /home/rsceben/work/waf/waf/waf-light clean configure build && cp build/*.json BuildGraph/
