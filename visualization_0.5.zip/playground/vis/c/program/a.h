int k = 123;
