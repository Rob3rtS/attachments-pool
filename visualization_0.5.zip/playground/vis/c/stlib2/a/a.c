int a()
{
    return 1;
}
