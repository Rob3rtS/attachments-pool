#include <stdio.h>
#include "b.h"

int main()
{
    printf("b=%d\n", b());
    
    return 0;
}
